# -*- coding: utf-8 -*-
import sys
from ecosysteme import *
from PyQt4 import QtCore, QtGui, uic

class InsectesUI(QtGui.QMainWindow):
    def __init__(self, nb_tours, nb_ins, *args):
        self.nb_tours = nb_tours
        self.nb_ins = nb_ins
        
        # on appelle le constructeur de la super classe
        QtGui.QMainWindow.__init__(self, *args)
        
        # et on charge l'interface graphique
        self.ui = uic.loadUi('insectes.ui', self)
        
        # pour l'instant on n'a pas d'écosystème
        self.ecosys = None
        
        # on charge l'image de fond
        palette= QtGui.QPalette()
        pixmap = QtGui.QPixmap("arrierPlan.png")
        palette.setBrush(QtGui.QPalette.Background,QtGui.QBrush(pixmap))
        self.setPalette(palette)
        self.painter = QtGui.QPainter()
        

            
if __name__ == "__main__":
    app = QtGui.QApplication(sys.argv)
    window = InsectesUI(50, 20)
    window.show()
    sys.exit(app.exec_())